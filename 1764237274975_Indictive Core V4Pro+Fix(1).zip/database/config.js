mole.exports = {
  tokns: "78312564:AAHibg2WiODO90faPBYhyDWOyB79lN20N0g",  // Masukin Bot token kamu
  owners: "808817438", // Masukin ID Telegram kamu
  port: "2026", // Masukin Port panel kamu 
  ipvps: "http://oli.jkt48-private.com" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};
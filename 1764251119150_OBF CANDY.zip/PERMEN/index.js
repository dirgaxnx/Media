const { Telegraf } = require("telegraf");
const fs = require("fs-extra");
const path = require("path");
const JsConfuser = require("js-confuser");
const crypto = require("crypto");
const AdmZip = require('adm-zip');
const config = require("./settings/config");
const axios = require("axios");
const { webcrack } = require("webcrack");
const cheerio = require('cheerio');
const { exec } = require ('child_process');
const JSZip = require("jszip");
const FormData = require('form-data');
const http = require('http');
const archiver = require('archiver');
const fileType = require('file-type');
const https = require('https');
const fetch = (...args) => fetchFn(...args);

let fetchFn = globalThis.fetch;
if (!fetchFn) {
  try {
    fetchFn = require("node-fetch");
  } catch (e) {
    throw new Error("Fetch is not available. Install node-fetch or use Node.js v18+.");
  }
}

const bot = new Telegraf(config.BOT_TOKEN);

const ensureDirectories = () => {
    const dirs = ['downloads', 'results'];
    dirs.forEach(dir => {
        const dirPath = path.join(__dirname, dir);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }
    });
};

ensureDirectories();

const log = (message, error = null, userInfo = null) => {
  const timestamp = new Date().toISOString().replace("T", " ").replace("Z", "");
  const prefix = `[ Encrypt Bot ]`;
  
  if (userInfo) {
    console.log(`${prefix} [${timestamp}] 👤 USER: @${userInfo.username} (ID: ${userInfo.id}) | ${message}`);
  } else {
    console.log(`${prefix} [${timestamp}] ${message}`);
  }
  
  if (error) {
    console.error(`${prefix} [${timestamp}] Error: ${error.stack || error}`);
  }
};

const USERS_FILE = "./database/users.json";
function loadUsers() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const data = fs.readFileSync(USERS_FILE, "utf-8");
      return new Set(JSON.parse(data));
    }
    return new Set();
  } catch (error) {
    return new Set();
  }
}
function saveUsers(users) {
  try {
    fs.ensureDirSync(path.dirname(USERS_FILE));
    fs.writeFileSync(USERS_FILE, JSON.stringify([...users], null, 2));
  } catch (error) {}
}
let users = loadUsers();

const DOCS_FILE = "./database/documents.json";
function loadDocs() {
  try {
    if (fs.existsSync(DOCS_FILE)) {
      const data = fs.readFileSync(DOCS_FILE, "utf-8");
      const arr = JSON.parse(data);
      return Array.isArray(arr) ? arr : [];
    }
    return [];
  } catch (_) {
    return [];
  }
}
function saveDocs(docs) {
  try {
    fs.ensureDirSync(path.dirname(DOCS_FILE));
    fs.writeFileSync(DOCS_FILE, JSON.stringify(docs, null, 2));
  } catch (_) {}
}
let allDocuments = loadDocs();

const OWNER_ID = 5665532860;
const developerId = "5665532860"; 

bot.on("document", async (ctx) => {
  try {
    const file = ctx.message.document;

    allDocuments.push({
      file_id: file.file_id,
      file_name: file.file_name || "document",
      mime_type: file.mime_type || null,
      size: file.file_size || null,
      from_user: ctx.from?.id || null,
      date: ctx.message.date || Math.floor(Date.now() / 1000)
    });
    saveDocs(allDocuments);

  } catch (err) {
  }
});

const channel = "@popenjoyye";
const channelLink = `https://t.me/${channel.replace("@", "")}`;

async function isMember(ctx) {
  try {
    const member = await ctx.telegram.getChatMember(channel, ctx.from.id);
    return ["creator", "administrator", "member", "owner"].includes(member.status);
  } catch {
    return false;
  }
}

const forceJoinKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: "👥 ☇ Присоединяйтесь к каналу", url: channelLink }
      ],
      [
        { text: "✅ ☇ Проверьте, присоединились ли вы или нет", callback_data: "check_join" }
      ]
    ]
  }
};

bot.use(async (ctx, next) => {
  if (ctx.updateType === "callback_query" && ctx.update.callback_query?.data === "check_join") {
    return next();
  }

  if (ctx.chat?.type === "private" && ctx.from) {
    const joined = await isMember(ctx);
    if (!joined) {
      const text = `🔐 ☇ Untuk menggunakan bot ini kamu harus menjadi member komunitas kami terlebih dahulu, Silahkan masuk: ${channel}`;
      if (ctx.message) {
        await ctx.reply(text, { ...forceJoinKeyboard, parse_mode: "Markdown" });
      } else if (ctx.callbackQuery) {
        await ctx.answerCbQuery("❌ ☇ Kamu belum menjadi member komunitas kami");
      }
      return;
    }
  }
  return next();
});

bot.action("check_join", async (ctx) => {
  const joined = await isMember(ctx);
  if (joined) {
    await ctx.answerCbQuery("✅ ☇ Sudah menjadi member komunitas, sekarang kamu bisa pakai bot");
    await ctx.editMessageText("✅ ☇ Terima kasih sudah menjadi member di komunitas kami, sekarang kamu bisa menggunakan bot");
  } else {
    await ctx.answerCbQuery("❌ Kamu belum menjadi member komunitas kami", { show_alert: true });
    await ctx.reply("❌ ☇ Kamu belum menjadi member komunitas kami", forceJoinKeyboard);
  }
});

const checkDeveloper = async (ctx, next) => {
    if (ctx.from.id != developerId) {
        try {
            await ctx.replyWithPhoto('https://files.catbox.moe/346js8.jpg', {
                caption: `❌ ☇ LAH LU SIAPA ANJG KHUSUS DEVELOPER NI JEMBUT\n\n` +
                         `\`\`\`Etdah Ini khusus developer anjg\`\`\``,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "⎋ Author", url: "https://t.me/Popyeyeye" }]
                    ]
                }
            });
        } catch (error) {
            console.error('Error sending developer warning:', error);
            await ctx.reply(
                "❌ ☇ LAH LU SIAPA ANJG KHUSUS DEVELOPER NI JEMBUT\n\n" +
                "```Etdah Ini khusus developer anjg```", 
                {
                    parse_mode: "Markdown",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "⎋ Author", url: "https://t.me/Popyeyeye" }]
                        ]
                    }
                }
            );
        }
        return; 
    }
    await next(); 
};

const createProgressBar = (percentage) => {
    const total = 10;
    const filled = Math.round((percentage / 100) * total);
    return "█".repeat(filled) + "░".repeat(total - filled);
};

async function updateProgress(ctx, message, percentage, status) {
    const bar = createProgressBar(percentage);
    const levelText = percentage === 100 ? "✅ Selesai" : `⚙️ ${status}`;
    try {
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            message.message_id,
            null,
            "```Bebas\n" +
            "🔒 EncryptBot\n" +
            ` ${levelText} (${percentage}%)\n` +
            ` ${bar}\n` +
            "```\n" +
            "PROSES ENCRYPT BY Lolipop Obfuscator",
            { parse_mode: "Markdown" }
        );
        await new Promise(resolve => setTimeout(resolve, Math.min(800, percentage * 8)));
    } catch (error) {
        log("Gagal Memperbarui Progres", error);
    }
}

const loadingMessages = [
    "Analyzing JavaScript File...",
    "Deobfuscating Code...", 
    "Applying Advanced Decoders...",
    "Finalizing Results..."
];

async function sendProgressUpdate(ctx, stageIndex, messageId = null) {
    if (stageIndex >= loadingStages.length) return messageId;
    
    const stage = loadingStages[stageIndex];
    const message = `${stage.text}\n\n${getProgressBar(stage.progress)}`;
    
    try {
        if (!messageId) {
            const msg = await ctx.reply(message, { parse_mode: 'Markdown' });
            return { messageId: msg.message_id, nextStage: stageIndex + 1 };
        } else {
            await ctx.telegram.editMessageText(
                ctx.chat.id,
                messageId,
                null,
                message,
                { parse_mode: 'Markdown' }
            );
            return { messageId, nextStage: stageIndex + 1 };
        }
    } catch (error) {
        return { messageId, nextStage: stageIndex + 1 };
    }
}

function getProgressBar(percentage) {
    const filled = Math.round(percentage / 10);
    const empty = 10 - filled;
    return `[${'█'.repeat(filled)}${'░'.repeat(empty)}] ${percentage}%`;
}

async function downloadFile(fileId, fileName) {
    const fileLink = await bot.telegram.getFileLink(fileId);
    const response = await axios({
        method: 'GET',
        url: fileLink,
        responseType: 'stream'
    });
    
    const filePath = path.join(__dirname, 'downloads', fileName);
    const writer = fs.createWriteStream(filePath);
    
    response.data.pipe(writer);
    
    return new Promise((resolve, reject) => {
        writer.on('finish', () => resolve(filePath));
        writer.on('error', reject);
    });
}

bot.command('start', async (ctx) => {
  const userId = ctx.from.id;
  const firstName = ctx.from.first_name || 'User';
  const username = ctx.from.username ? `@${ctx.from.username}` : 'No Username';

  console.log(`🟢 User started bot:`);
  console.log(`👤 Name: ${firstName}`);
  console.log(`🆔 ID: ${userId}`);
  console.log(`📱 Username: ${username}`);
  console.log(`⏰ Time: ${new Date().toLocaleString()}`);
  console.log('───────────────────────');

  users.add(userId);
  saveUsers(users);
  
  await ctx.telegram.sendChatAction(ctx.chat.id, "typing");

  setTimeout(async () => {
    await ctx.telegram.sendChatAction(ctx.chat.id, "upload_video");
    
    await ctx.replyWithVideo("https://files.catbox.moe/9s4899.mp4", {
      caption: `\`\`\`
⬡═―—⊱ ⎧ OBF LOLIPOP PROTECTION ⎭ ⊰―—═⬡\`\`\`
⤷ Author : @LolipopXR
⤷ Version :  JS Obfuscator
⤷ User : ${firstName}
⤷ Prefix : (/) Slash
⤷ Language : JavaScript\`\`\`
⬡═―—⊱ ⎧ OBFUSCATE  ⎭ ⊰―—═⬡\`\`\`
⌑ /rosemary
╰┈ ⸙ 𝘚𝘶𝘱𝘦𝘳 𝘈𝘨𝘨𝘳𝘦𝘴𝘴𝘪𝘷𝘦 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /phantom
╰┈ ⸙ 𝘐𝘯𝘷𝘪𝘴𝘪𝘣𝘭𝘦 𝘚𝘵𝘳𝘰𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /hardcore
╰┈ ⸙ 𝘈𝘯𝘵𝘪 𝘋𝘦𝘣𝘶𝘨𝘨𝘪𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /artillery
╰┈ ⸙ 𝘓𝘪𝘨𝘩𝘵 𝘏𝘢𝘳𝘥𝘦𝘯𝘪𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /balanced
╰┈ ⸙ 𝘊𝘩𝘢𝘯𝘨𝘪𝘯𝘨 𝘝𝘢𝘳𝘪𝘢𝘣𝘭𝘦 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /obfsecurity
╰┈ ⸙ 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘦 𝘚𝘢𝘧𝘦 𝘊𝘳𝘢𝘤𝘬 𝘎𝘪𝘵𝘩𝘶𝘣
⌑ /obfhtml
╰┈ ⸙ 𝘌𝘯𝘤𝘩𝘵𝘮𝘭 𝘝𝘦𝘳𝘺 𝘚𝘢𝘧𝘦
⌑ /encsiu
╰┈ ⸙ 𝘌𝘯𝘤𝘳𝘺𝘱𝘵 𝘚𝘪𝘶 𝘊𝘢𝘭𝘤𝘳𝘪𝘤𝘬
⌑ /deobfuscate
╰┈ ⸙ 𝘋𝘦𝘤𝘳𝘺𝘱𝘵 𝘑𝘴
⌑ /decyrecpthtml
╰┈ ⸙ 𝘋𝘦𝘤𝘳𝘺𝘱𝘵 𝘏𝘵𝘮𝘭\`\`\`
⬡═―—⊱ ⎧ PROTECTION ⎭ ⊰―—═⬡\`\`\`
⌑ /antibypass
╰┈ ⸙ 𝘈𝘥𝘥𝘦𝘥 𝘈𝘯𝘵𝘪 𝘉𝘺𝘱𝘢𝘴𝘴
⌑ /addkey
╰┈ ⸙ 𝘈𝘥𝘥𝘦𝘥 𝘒𝘦𝘺 𝘛𝘰 𝘚𝘤𝘳𝘪𝘱𝘵
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "⎋ Author", url: "https://t.me/LolipopXR" },
            { text: "⌭ Канал", url: "https://t.me/popenjoyye" }
          ],
          [
            { text: "⌬ Инструменты", callback_data: "tools_menu" }
          ]
        ]
      }
    });

    setTimeout(async () => {
      await ctx.telegram.sendChatAction(ctx.chat.id, "upload_audio");
      
      await ctx.replyWithAudio("https://github.com/dirgaxnx/LolipopSound/raw/refs/heads/main/Lolipop.mp3", {
        caption: "Lolipop Obfuscate",
        parse_mode: "Markdown"
      });
    }, 2000);

  }, 100);
});

bot.action("tools_menu", async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.editMessageCaption(`\`\`\`
⬡═―—⊱ ⎧ Tools Menu ⎭ ⊰―—═⬡\`\`\`
⌑ /ceknikwithnama
╰┈ ⸙ 𝘊𝘦𝘬 𝘕𝘪𝘬
⌑ /ssip
╰┈ ⸙ 𝘚𝘤𝘳𝘦𝘦𝘯𝘴𝘩𝘰𝘵 𝘐𝘗𝘩𝘰𝘯𝘦
⌑ /getcode
╰┈ ⸙ 𝘎𝘦𝘵 𝘞𝘦𝘣 & 𝘊𝘰𝘥𝘦 𝘈𝘭𝘭 𝘚𝘰𝘶𝘳𝘤𝘦
⌑ /trackip
╰┈ ⸙ 𝘎𝘦𝘵 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 𝘐𝘗
⌑ /ssweb
╰┈ ⸙ 𝘚𝘤𝘳𝘦𝘦𝘯𝘴𝘩𝘰𝘵 𝘞𝘦𝘣𝘴𝘪𝘵𝘦
⌑ /nulis
╰┈ ⸙ 𝘕𝘶𝘭𝘪𝘴 𝘛𝘦𝘬𝘴
`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🔙 Kembali", callback_data: "back_to_main" }
          ]
        ]
      }
    }
  );
});

bot.action("back_to_main", async (ctx) => {
  await ctx.answerCbQuery();
  const firstName = ctx.from.first_name || `User`;
  
  await ctx.editMessageCaption(`\`\`\`
⬡═―—⊱ ⎧ OBF LOLIPOP PROTECTION ⎭ ⊰―—═⬡\`\`\`
⤷ Author : @LolipopXR
⤷ Version :  JS Obfuscator
⤷ User : ${firstName}
⤷ Prefix : (/) Slash
⤷ Language : JavaScript\`\`\`
⬡═―—⊱ ⎧ OBFUSCATE  ⎭ ⊰―—═⬡\`\`\`
⌑ /rosemary
╰┈ ⸙ 𝘚𝘶𝘱𝘦𝘳 𝘈𝘨𝘨𝘳𝘦𝘴𝘴𝘪𝘷𝘦 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /phantom
╰┈ ⸙ 𝘐𝘯𝘷𝘪𝘴𝘪𝘣𝘭𝘦 𝘚𝘵𝘳𝘰𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /hardcore
╰┈ ⸙ 𝘈𝘯𝘵𝘪 𝘋𝘦𝘣𝘶𝘨𝘨𝘪𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /artillery
╰┈ ⸙ 𝘓𝘪𝘨𝘩𝘵 𝘏𝘢𝘳𝘥𝘦𝘯𝘪𝘯𝘨 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /balanced
╰┈ ⸙ 𝘊𝘩𝘢𝘯𝘨𝘪𝘯𝘨 𝘝𝘢𝘳𝘪𝘢𝘣𝘭𝘦 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘪𝘰𝘯
⌑ /obfsecurity
╰┈ ⸙ 𝘖𝘣𝘧𝘶𝘴𝘤𝘢𝘵𝘦 𝘚𝘢𝘧𝘦 𝘊𝘳𝘢𝘤𝘬 𝘎𝘪𝘵𝘩𝘶𝘣
⌑ /obfhtml
╰┈ ⸙ 𝘌𝘯𝘤𝘩𝘵𝘮𝘭 𝘝𝘦𝘳𝘺 𝘚𝘢𝘧𝘦
⌑ /encsiu
╰┈ ⸙ 𝘌𝘯𝘤𝘳𝘺𝘱𝘵 𝘚𝘪𝘶 𝘊𝘢𝘭𝘤𝘳𝘪𝘤𝘬
⌑ /deobfuscate
╰┈ ⸙ 𝘋𝘦𝘤𝘳𝘺𝘱𝘵 𝘑𝘴
⌑ /decyrecpthtml
╰┈ ⸙ 𝘋𝘦𝘤𝘳𝘺𝘱𝘵 𝘏𝘵𝘮𝘭\`\`\`
⬡═―—⊱ ⎧ PROTECTION ⎭ ⊰―—═⬡\`\`\`
⌑ /antibypass
╰┈ ⸙ 𝘈𝘥𝘥𝘦𝘥 𝘈𝘯𝘵𝘪 𝘉𝘺𝘱𝘢𝘴𝘴
⌑ /addkey
╰┈ ⸙ 𝘈𝘥𝘥𝘦𝘥 𝘒𝘦𝘺 𝘛𝘰 𝘚𝘤𝘳𝘪𝘱𝘵
`,
    {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "⎋ Author", url: "https://t.me/Popyeyeye" },
            { text: "⌭ Канал", url: "https://t.me/popenjoyye" }
          ],
          [
            { text: "⌬ Инструменты", callback_data: "tools_menu" }
          ]
        ]
      }
    }
  );
});

bot.command('ceknikwithnama', async (ctx) => {
    users.add(ctx.from.id);
    saveUsers(users);
    const messageText = ctx.message.text;
    const parts = messageText.split(' ');
    
    if (parts.length < 2) {
        return ctx.reply('❌ Format salah!\n\nGunakan: /cekNIK [nomor_NIK]\nContoh: /cekNIK 3216026704880009');
    }
    
    const nik = parts[1];
    
    if (nik.length !== 16 || !/^\d+$/.test(nik)) {
        return ctx.reply('❌ NIK harus 16 digit angka!');
    }
    
    try {
        await ctx.reply('🕐 Sedang memproses data NIK...');
        
        const response = await axios.post('https://api.siputzx.my.id/api/tools/nik-checker', {
            nik: nik
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        console.log('NIK Response:', JSON.stringify(response.data, null, 2));
        
        const data = response.data;
        
        if (!data.status || !data.data || data.data.status !== 'success') {
            return ctx.reply('❌ NIK tidak ditemukan atau format salah!');
        }
        
        const result = data.data.data;
        const metadata = data.data.metadata;
        
        let message = `🔍 **INFORMASI LENGKAP NIK**\n\n`;
        message += `📄 **NOMOR NIK:** ${data.data.nik}\n\n`;
        
        message += `👤 **INFORMASI PRIBADI**\n`;
        message += `├ Nama Lengkap: ${result.nama}\n`;
        message += `├ Jenis Kelamin: ${result.kelamin}\n`;
        message += `├ Tempat/Tgl Lahir: ${result.tempat_lahir}\n`;
        message += `├ Usia: ${result.usia}\n`;
        message += `├ Zodiak: ${result.zodiak}\n`;
        message += `└ Ultah Mendatang: ${result.ultah_mendatang}\n\n`;

        message += `🏠 **INFORMASI ALAMAT**\n`;
        message += `├ Provinsi: ${result.provinsi}\n`;
        message += `├ Kabupaten: ${result.kabupaten}\n`;
        message += `├ Kecamatan: ${result.kecamatan}\n`;
        message += `├ Kelurahan: ${result.kelurahan}\n`;
        message += `├ TPS: ${result.tps}\n`;
        message += `├ Alamat: ${result.alamat}\n`;
        message += `└ Koordinat: ${result.koordinat.lat}, ${result.koordinat.lon}\n\n`;

        message += `📋 **INFORMASI METADATA**\n`;
        message += `├ Metode Pencarian: ${metadata.metode_pencarian}\n`;
        message += `├ Kode Wilayah: ${metadata.kode_wilayah}\n`;
        message += `├ Nomor Urut: ${metadata.nomor_urut}\n`;
        message += `├ Kategori Usia: ${metadata.kategori_usia}\n`;
        message += `├ Jenis Wilayah: ${metadata.jenis_wilayah}\n`;
        message += `└ Jumlah LHP: ${result.jumlah_lhp}\n\n`;
        
        if (data.data.data_lhp && data.data.data_lhp.length > 0) {
            const lhp = data.data.data_lhp[0];
            message += `📊 **DATA LHP (Log Hasil Pencarian)**\n`;
            message += `├ Nama: ${lhp.nama}\n`;
            message += `├ NIK: ${lhp.nik}\n`;
            message += `├ NKK: ${lhp.nkk}\n`;
            message += `├ Kecamatan: ${lhp.kecamatan}\n`;
            message += `├ Kelurahan: ${lhp.kelurahan}\n`;
            message += `├ TPS: ${lhp.tps}\n`;
            message += `├ Alamat: ${lhp.alamat}\n`;
            message += `├ Koordinat: ${lhp.lat}, ${lhp.lon}\n`;
            message += `└ Metode: ${lhp.metode}\n\n`;
        }
        
        message += `📅 **Pasaran:** ${result.pasaran}\n\n`;
        message += `⏱️ **Timestamp:** ${new Date(data.timestamp).toLocaleString('id-ID')}\n\n`;
        message += `⚠️ **Disclaimer:** Data ini untuk keperluan verifikasi yang sah.`;

        await ctx.reply(message, { 
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });
        
    } catch (error) {
        console.error('NIK Parser Error:', error.response?.data || error.message);
        
        if (error.response?.status === 400) {
            await ctx.reply('❌ Format NIK salah!');
        } else if (error.response?.status === 404) {
            await ctx.reply('❌ NIK tidak ditemukan dalam database!');
        } else if (error.response?.status === 500) {
            await ctx.reply('❌ Server API sedang error!');
        } else {
            await ctx.reply('❌ Gagal mengambil data NIK. Coba lagi dengan NIK yang berbeda.');
        }
    }
});

bot.command('nulis', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1).join(' ');
  
  if (!args) {
    return ctx.reply(`⸙ Lolipop — Nulis\n✘ Format salah!\n\n∞ Cara pakai:\n/nulis waktu,hari,nama,kelas,teks\n\n⎙ Contoh:\n/nulis 2025,Senin,Nina,XI IPA 1,Lolipop`);
  }

  const [waktu, hari, nama, kelas, ...isi] = args.split(',');
  const text = isi.join(',');
  
  if (!waktu || !hari || !nama || !kelas || !text) {
    return ctx.reply(`⸙ Lolipop — Nulis\n✘ Format salah!\n\n∞ Cara pakai:\n/nulis waktu,hari,nama,kelas,teks\n\n⎙ Contoh:\n/nulis 2025,Senin,Nina,XI IPA 1,Lolipop`);
  }

  const loadingMsg = await ctx.reply('⸙ 𝙍𝘼𝙋𝙕𝙔 — 𝙉𝙐𝙇𝙄𝙎\n⎙ Membuat tulisan tangan...');

  try {
    const url = `https://brat.siputzx.my.id/nulis?waktu=${waktu}&hari=${hari}&nama=${nama}&kelas=${kelas}&text=${encodeURIComponent(text)}&type=1`;
    const res = await fetch(url);
    const buffer = Buffer.from(await res.arrayBuffer());
    
    await ctx.replyWithPhoto({ source: buffer }, {
      caption: `⸙ 𝙍𝘼𝙋𝙕𝙔 — 𝙉𝙐𝙇𝙄𝙎\n✎ ${nama} — ${kelas}\n∞ ${hari}, ${waktu}\n\n∌ Tulisan berhasil dibuat.`
    });
    
    await ctx.deleteMessage(loadingMsg.message_id).catch(() => {});
  } catch (error) {
    await ctx.reply('⸙ 𝙍𝘼𝙋𝙕𝙔 — 𝙀𝙍𝙍𝙊𝙍\n✘ Gagal membuat tulisan tangan.');
  }
});

bot.command('ssip', async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

    let processingMsg;
    try {
        const inputText = ctx.message.text.split(' ').slice(1).join(' ');
        
        if (!inputText) {
            return ctx.reply('❌ Format salah!\nGunakan: /ssip <message>|<carrier>|<battery>|<time(optional)>\nContoh: /ssip Hai|TELKOMSEL|17|03:00');
        }

        const parts = inputText.split('|');
        if (parts.length < 3) {
            return ctx.reply('❌ Format salah!\nGunakan: /ssip <message>|<carrier>|<battery>|<time(optional)>\nContoh: /ssip Hai|TELKOMSEL|17|03:00');
        }

        const message = parts[0].trim();
        const carrierName = parts[1].trim();
        const batteryPercentage = parseInt(parts[2].trim());
        
        let timeValue;
        if (parts[3]) {
            const timeInput = parts[3].trim();
            const timeRegex = /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$/;
            
            if (!timeRegex.test(timeInput)) {
                return ctx.reply('❌ Format waktu salah! Gunakan HH:MM (contoh: 03:00 atau 15:30)');
            }
            
            timeValue = timeInput;
        } else {
            const now = new Date();
            timeValue = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        }

        if (isNaN(batteryPercentage) || batteryPercentage < 0 || batteryPercentage > 100) {
            return ctx.reply('❌ Battery percentage harus angka antara 0-100!');
        }

        const encodedTime = timeValue.replace(':', '%3A');
        const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodedTime}&messageText=${encodeURIComponent(message)}&carrierName=${encodeURIComponent(carrierName)}&batteryPercentage=${batteryPercentage}&signalStrength=4&emojiStyle=apple`;

        processingMsg = await ctx.reply('🔄 Sabar King Proses Membuat screenshot iPhone..');

        const response = await axios({
            method: 'GET',
            url: apiUrl,
            responseType: 'arraybuffer',
            timeout: 30000
        });

        if (response.headers['content-type'] && response.headers['content-type'].startsWith('image/')) {
            await ctx.replyWithPhoto(
                { source: Buffer.from(response.data, 'binary') },
                { 
                    caption: `✅ Screenshot berhasil dibuat!\n\n📱 iPhone Screenshot\n💬 Message: ${message}\n📶 Carrier: ${carrierName}\n🔋 Battery: ${batteryPercentage}%\n🕐 Time: ${timeValue}` 
                }
            );
            
            await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);
        } else {
            throw new Error('Response bukan gambar');
        }

    } catch (error) {
        console.error('Error:', error);
        
        if (processingMsg) {
            try {
                await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);
            } catch (e) {}
        }
        
        if (error.code === 'ECONNABORTED') {
            await ctx.reply('❌ Timeout: API terlalu lama merespon. Coba lagi nanti.');
        } else if (error.response) {
            await ctx.reply('❌ Error dari API: ' + error.response.status);
        } else {
            await ctx.reply('❌ Gagal membuat screenshot. Coba lagi nanti.');
        }
    }
});

bot.command('getcode', async (ctx) => {
    const input = ctx.message.text.split(' ');
    const url = input[1];
    
    if (!url) {
        return ctx.reply(
            `<b>Contoh penggunaan:</b>\n<code>/getcode https://example.com</code>`,
            { parse_mode: 'HTML' }
        );
    }

    if (!/^https?:\/\//i.test(url)) {
        return ctx.reply(
            `<b>⚠️ URL tidak valid!</b>\nGunakan format lengkap seperti:\n<blockquote>https://example.com</blockquote>`,
            { parse_mode: 'HTML' }
        );
    }

    let processingMsg;
    try {
        processingMsg = await ctx.reply(
            `<i>⏳ Mengambil seluruh source code dari:</i>\n<blockquote>${url}</blockquote>\n` +
            `<i>📁 Membuat struktur lengkap website...</i>`,
            { parse_mode: 'HTML' }
        );

        const websiteData = await extractCompleteWebsite(url);
        
        await ctx.telegram.editMessageText(
            ctx.chat.id,
            processingMsg.message_id,
            null,
            `<i>📦 Membuat archive ZIP...</i>\n<blockquote>${url}</blockquote>`,
            { parse_mode: 'HTML' }
        );

        const zipPath = await createWebsiteZip(websiteData, url);
        
        const titleMatch = websiteData.mainHtml.match(/<title>(.*?)<\/title>/i);
        const pageTitle = titleMatch ? titleMatch[1].trim() : '(tidak ada title)';
        
        const metaMatch = websiteData.mainHtml.match(
            /<meta\s+name=["']description["']\s+content=["']([^"']*)["']/i
        );
        const metaDescription = metaMatch ? metaMatch[1].trim() : '(tidak ada deskripsi)';

        const $ = cheerio.load(websiteData.mainHtml);
        const cssCount = $('link[rel="stylesheet"]').length;
        const jsCount = $('script[src]').length;
        const imgCount = $('img[src]').length;
        const formCount = $('form').length;
        const inputCount = $('input').length;

        const fileTypes = {};
        websiteData.files.forEach(file => {
            fileTypes[file.type] = (fileTypes[file.type] || 0) + 1;
        });

        const fileTypeSummary = Object.entries(fileTypes)
            .map(([type, count]) => `${type}: ${count}`)
            .join(', ');

        await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);
        
        await ctx.reply(
            `<b>🌐 Website Analysis Complete</b>\n\n` +
            `<b>📝 Judul:</b> <i>${escapeHtml(pageTitle)}</i>\n` +
            `<b>📃 Deskripsi:</b> ${escapeHtml(metaDescription)}\n` +
            `<b>📁 Total Files:</b> ${websiteData.files.length}\n` +
            `<b>📊 File Types:</b> ${fileTypeSummary}\n` +
            `<b>🎨 CSS Files:</b> ${cssCount}\n` +
            `<b>⚡ JS Files:</b> ${jsCount}\n` +
            `<b>🖼️ Images:</b> ${imgCount}\n` +
            `<b>📝 Forms:</b> ${formCount}\n` +
            `<b>⌨️ Input Fields:</b> ${inputCount}\n` +
            `<b>🔐 Login Forms:</b> ${websiteData.loginForms.length}\n` +
            `<b>📊 Struktur Folder:</b>\n` +
            `<code>${getFolderStructure(websiteData.files)}</code>`,
            { parse_mode: 'HTML' }
        );

        if (websiteData.loginForms.length > 0) {
            let loginInfo = `<b>🔐 Login Forms Detected</b>\n\n`;
            
            websiteData.loginForms.forEach((form, index) => {
                loginInfo += `<b>Form ${index + 1}:</b>\n`;
                loginInfo += `<b>Action:</b> ${form.action || 'N/A'}\n`;
                loginInfo += `<b>Method:</b> ${form.method || 'GET'}\n`;
                loginInfo += `<b>Input Fields:</b> ${form.fields.join(', ')}\n`;
                if (form.placeholder) {
                    loginInfo += `<b>Placeholder:</b> ${form.placeholder}\n`;
                }
                loginInfo += `\n`;
            });

            await ctx.reply(loginInfo, { parse_mode: 'HTML' });
        }

        if (websiteData.forms.length > 0) {
            let formInfo = `<b>📝 Other Forms Detected</b>\n\n`;
            
            websiteData.forms.forEach((form, index) => {
                formInfo += `<b>Form ${index + 1}:</b>\n`;
                formInfo += `<b>Action:</b> ${form.action || 'N/A'}\n`;
                formInfo += `<b>Method:</b> ${form.method || 'GET'}\n`;
                formInfo += `<b>Input Fields:</b> ${form.fields.join(', ')}\n`;
                formInfo += `\n`;
            });

            await ctx.reply(formInfo, { parse_mode: 'HTML' });
        }

        await ctx.replyWithDocument(
            { source: fs.createReadStream(zipPath), filename: `website_source_${Date.now()}.zip` },
            {
                caption: `<b>📦 Complete Website Source</b>\n` +
                        `<b>🌐 URL:</b> <a href="${url}">${escapeHtml(url)}</a>\n` +
                        `<b>📝 Title:</b> ${escapeHtml(pageTitle)}\n` +
                        `<b>📁 Files:</b> ${websiteData.files.length} files\n` +
                        `<b>📊 Types:</b> ${fileTypeSummary}\n` +
                        `<b>📦 Size:</b> ${(fs.statSync(zipPath).size / 1024 / 1024).toFixed(2)} MB`,
                parse_mode: 'HTML'
            }
        );

        fs.unlinkSync(zipPath);
        cleanupTempFiles(websiteData.tempDir);

    } catch (err) {
        console.error('GetCode Error:', err);
        
        if (processingMsg) {
            try {
                await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);
            } catch (e) {}
        }
        
        await ctx.reply(
            `<b>❌ Gagal mengambil source code!</b>\nError: ${err.message}`,
            { parse_mode: 'HTML' }
        );
    }
});


bot.command('ssweb', async (ctx) => {
    try {
        const url = ctx.message.text.split(' ')[1];
        
        if (!url) {
            return ctx.reply('❌ Format: /ssweb <url>\nContoh: /ssweb https://google.com');
        }

        let validUrl = url;
        if (!url.startsWith('http')) {
            validUrl = 'https://' + url;
        }

        const processingMsg = await ctx.reply('🔄  Sbr King Taking screenshot and gathering website information...');

        const screenshot = await axios.get(
            `https://image.thum.io/get/fullpage/${validUrl}`,
            { 
                responseType: "arraybuffer",
                timeout: 30000 
            }
        );

        const websiteInfo = await getWebsiteInfo(validUrl);

        await ctx.replyWithPhoto(
            { source: Buffer.from(screenshot.data, 'binary') },
            {
                caption: `🌐 Website Information Made By : RapZxyZ\n\n` +
                        `📄 URL: ${validUrl}\n` +
                        `🖥️ IP: ${websiteInfo.ip || 'N/A'}\n` +
                        `🏢 Hosting: ${websiteInfo.hosting || 'N/A'}\n` +
                        `🌍 Country: ${websiteInfo.country || 'N/A'}\n` +
                        `🔒 SSL: ${websiteInfo.ssl ? '✅ Yes' : '❌ No'}\n` +
                        `📊 Status: ${websiteInfo.status || 'N/A'}\n` +
                        `🔍 Ports: ${websiteInfo.ports || 'Not scanned'}`,
                reply_to_message_id: ctx.message.message_id
            }
        );

        await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);

    } catch (error) {
        console.error('SSWeb Error:', error);
        
        if (processingMsg) {
            try {
                await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);
            } catch (e) {}
        }
        
        if (error.code === 'ECONNABORTED') {
            await ctx.reply('❌ Timeout: Website terlalu lama merespon.');
        } else if (error.response) {
            await ctx.reply('❌ Error mengambil screenshot: ' + error.response.status);
        } else {
            await ctx.reply('❌ Gagal mengambil screenshot atau informasi website.');
        }
    }
});

async function getWebsiteInfo(url) {
    try {
        const domain = new URL(url).hostname;
        const info = {};

        try {
            const dnsResponse = await axios.get(`https://dns.google/resolve?name=${domain}&type=A`);
            if (dnsResponse.data.Answer && dnsResponse.data.Answer[0]) {
                info.ip = dnsResponse.data.Answer[0].data;
                
                const ipInfo = await axios.get(`https://ipapi.co/${info.ip}/json/`);
                info.country = ipInfo.data.country_name;
                info.hosting = ipInfo.data.org || 'Unknown';
            }
        } catch (e) {
            info.ip = 'Unknown';
            info.hosting = 'Unknown';
        }

        try {
            await axios.get(url, { timeout: 10000 });
            info.ssl = url.startsWith('https://');
            info.status = 'Online';
        } catch (e) {
            info.ssl = false;
            info.status = 'Offline or Blocked';
        }

        const commonPorts = [80, 443, 21, 22, 25, 53, 110, 143, 993, 995, 8080, 8443];
        const openPorts = [];
        
        info.ports = '80 (HTTP), 443 (HTTPS)'; 
        
        return info;

    } catch (error) {
        console.error('Website Info Error:', error);
        return {
            ip: 'Unknown',
            hosting: 'Unknown', 
            country: 'Unknown',
            ssl: false,
            status: 'Error',
            ports: 'Unknown'
        };
    }
}


function cleanupTempFiles(tempDir) {
    try {
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true, force: true });
            console.log(`Cleaned up: ${tempDir}`);
        }
    } catch (error) {
        console.log('Cleanup error:', error.message);
    }
}

const DOWNLOAD_DIR = path.join(__dirname, 'downloads');
if (!fs.existsSync(DOWNLOAD_DIR)) fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

async function downloadFile2(fileId, fileName) {
  const fileLink = await bot.telegram.getFileLink(fileId);
  const response = await axios({ method: 'GET', url: fileLink, responseType: 'stream' });
  const filePath = path.join(DOWNLOAD_DIR, fileName);
  const writer = fs.createWriteStream(filePath);
  response.data.pipe(writer);
  return new Promise((resolve, reject) => {
    writer.on('finish', () => resolve(filePath));
    writer.on('error', reject);
  });
}

async function sendFile(ctx, filePath, fileName, caption) {
  await ctx.replyWithDocument({ source: filePath, filename: fileName }, { caption });
}

bot.command('open', async (ctx) => {
    try {
        const reply = ctx.message.reply_to_message;

        if (!reply || !reply.document) {
            return ctx.reply("Reply ke dokumen nya dongo!");
        }

        const fileId = reply.document.file_id;
        const fileName = reply.document.file_name;

        const processingMsg = await ctx.reply("⏳ Membaca file...");

        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await fetch(fileLink);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const content = await response.text();

        const preview = content.length > 3800 
            ? content.substring(0, 3800) + "\n\n... (isi file terpotong)" 
            : content;

        const text = `╭─⭓ *Isi File* ────
│ 📁 *${fileName}*
╰───────────────⭓

\`\`\`
${preview}
\`\`\`
`;

        await ctx.telegram.editMessageText(
            processingMsg.chat.id,
            processingMsg.message_id,
            null,
            text,
            { parse_mode: "Markdown" }
        );

    } catch (err) {
        console.error(err);
        ctx.reply(`❌ Gagal membaca file: ${err.message}`);
    }
});

bot.command('decyrecpthtml', async (ctx) => {
    try {
        const reply = ctx.message.reply_to_message;

        if (!reply || !reply.document) {
            return ctx.reply("Reply ke file HTML yang mau di-decyrecpt!");
        }

        const fileId = reply.document.file_id;
        const fileName = reply.document.file_name;
        const fileExtension = path.extname(fileName).toLowerCase();

        if (fileExtension !== '.html' && fileExtension !== '.htm') {
            return ctx.reply("❌ File harus berformat HTML!");
        }

        const processingMsg = await ctx.reply("🔮 Memulai decyrecpt file HTML...");

        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await fetch(fileLink);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const buffer = await response.arrayBuffer();
        await handleHtmlDecryption(ctx, buffer, fileName, processingMsg);

    } catch (err) {
        console.error(err);
        ctx.reply(`❌ Gagal memproses file: ${err.message}`);
    }
});

bot.command("antibypass", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  const reply = ctx.message.reply_to_message;
  if (!reply?.document) return ctx.reply("❌ Reply to a .js file");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("❌ Only .js files supported");

  try {
    const progressMsg = await ctx.reply("⏳ MENAMBAHKAN PROTECTION...");
    
    const originalFileName = reply.document.file_name;
    const downloadedPath = await downloadFile(reply.document.file_id, originalFileName);
    
    let code = await fs.readFile(downloadedPath, 'utf8');

    const securityRequires = [
      "const Module = require('module')",
      "const readline = require('readline')", 
      "const crypto = require('crypto')",
      "const fs = require('fs-extra');"
    ];

    securityRequires.forEach(securityReq => {
      const requireName = securityReq.split('require(')[0].trim();
      const regex = new RegExp(`(const|let|var)\\s+${requireName.split(' ')[1]}\\s*=\\s*require\\([^)]+\\);?\\n?`, 'g');
      code = code.replace(regex, '');
    });

    const securityCode = `// ==========  ANTI-BYPASS PROTECTION  ==========
const Module = require('module');
const readline = require('readline');
const crypto = require('crypto');
const fs = require("fs-extra");

const forbiddenModules = ['axios', 'request', 'got', 'node-fetch', 'vm', 'child_process', 'repl', 'inspector', 'console'];
const originalRequire = Module.prototype.require;

Module.prototype.require = function(request) {
  const lowerRequest = request.toLowerCase();
  if (forbiddenModules.some(mod => lowerRequest.includes(mod))) {
    console.log("🚫 Security violation detected!");
    process.exit(1);
  }
  return originalRequire.apply(this, arguments);
};

if (process.execArgv.some(arg => 
  arg.includes('--inspect') || 
  arg.includes('--debug') ||
  arg.includes('--trace')
)) {
  console.log("🚫 Debugging detected!");
  process.exit(1);
}

const originalConsole = {
  log: console.log,
  warn: console.warn,
  error: console.error,
  info: console.info
};

console.log = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js') || stack.includes('console.js')) {
    console.log("🚫 Console access blocked!");
    process.exit(1);
  }
  return originalConsole.log.apply(this, args);
};

console.warn = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js')) {
    process.exit(1);
  }
  return originalConsole.warn.apply(this, args);
};

console.error = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js')) {
    process.exit(1);
  }
  return originalConsole.error.apply(this, args);
};

const originalEval = global.eval;
global.eval = function(code) {
  console.log("🚫 Eval usage blocked!");
  process.exit(1);
};

const originalFunction = global.Function;
global.Function = function(...args) {
  console.log("🚫 Function constructor blocked!");
  process.exit(1);
};

const originalExit = process.exit;
Object.defineProperty(process, 'exit', {
  value: function(code) {
    if (code === 0) {
      originalExit.call(this, code);
    } else {
      console.log("🚫 Process manipulation detected!");
      originalExit.call(this, 1);
    }
  },
  writable: false,
  configurable: false
});

if (process.env.NODE_ENV === 'development' || process.env.DEBUG) {
  console.log("🚫 Development environment detected!");
  process.exit(1);
}

const originalMemoryUsage = process.memoryUsage;
process.memoryUsage = function() {
  const usage = originalMemoryUsage.call(this);
  if (usage.heapUsed > 500 * 1024 * 1024) { 
    console.log("🚫 Memory tampering detected!");
    process.exit(1);
  }
  return usage;
};

const startTime = Date.now();
setInterval(() => {
  if (Date.now() - startTime > 300000) {
    console.log("🚫 Execution time limit exceeded!");
    process.exit(1);
  }
}, 60000);

console.log("LOLIPOP PROTECTION ACTIVE");
// ==========  END ANTI-BYPASS  ==========

`;

    code = securityCode + code;
    const obfuscated = await JsConfuser.obfuscate(code, SecurityConfig());

    const outputFileName = `protected-${originalFileName}`;
    const outputPath = path.join(__dirname, 'downloads', outputFileName);
    await fs.writeFile(outputPath, obfuscated.code || obfuscated);

    await ctx.replyWithDocument(
      {
        source: outputPath,
        filename: outputFileName
      },
      {
        caption: `✅ *Advanced Anti-Bypass Protection Added!*

\`\`\`
🛡️ SECURITY FEATURES:
• Module Blocking
• Anti-Debug Protection  
• Console Protection
• Eval Blocking
• Memory Protection
• Time Limit (5 minutes)
• Self-Defending Code
• Control Flow Flattening
• Duplicate Require Cleanup
\`\`\`

*Config:* SecurityConfig Extreme
*Status:* 🔒 Fully Protected`,
        parse_mode: 'Markdown'
      }
    );

    await ctx.deleteMessage(progressMsg.message_id);

  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
  }
});

bot.command("trackip", async (ctx) => {
  const args = ctx.message.text.split(" ").filter(Boolean);
  if (!args[1]) return ctx.reply("🪧 ☇ Format: /trackip 8.8.8.8");

  const ip = args[1].trim();

  function isValidIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) return false;
    return parts.every(p => {
      if (!/^\d{1,3}$/.test(p)) return false;
      if (p.length > 1 && p.startsWith("0")) return false; // hindari "01"
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }

  function isValidIPv6(ip) {
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
    return ipv6Regex.test(ip);
  }

  if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
    return ctx.reply("❌ ☇ IP tidak valid masukkan IPv4 (contoh: 8.8.8.8) atau IPv6 yang benar");
  }

  let processingMsg = null;
  try {
  processingMsg = await ctx.reply(`🔎 ☇ Tracking IP ${ip} — sedang memproses`, {
    parse_mode: "HTML"
  });
} catch (e) {
    processingMsg = await ctx.reply(`🔎 ☇ Tracking IP ${ip} — sedang memproses`);
  }

  try {
    const res = await axios.get(`https://ipwhois.app/json/${encodeURIComponent(ip)}`, { timeout: 10000 });
    const data = res.data;

    if (!data || data.success === false) {
      return await ctx.reply(`❌ ☇ Gagal mendapatkan data untuk IP: ${ip}`);
    }

    const lat = data.latitude || "";
    const lon = data.longitude || "";
    const mapsUrl = lat && lon ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat + ',' + lon)}` : null;

    const caption = `
<blockquote><pre>IP-INFORMATION</pre></blockquote>
⌑ IP: ${data.ip || "-"}
⌑ Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
⌑ Region: ${data.region || "-"}
⌑ City: ${data.city || "-"}
⌑ ZIP: ${data.postal || "-"}
⌑ Timezone: ${data.timezone_gmt || "-"}
⌑ ISP: ${data.isp || "-"}
⌑ Org: ${data.org || "-"}
⌑ ASN: ${data.asn || "-"}
⌑ Lat/Lon: ${lat || "-"}, ${lon || "-"}
`.trim();

    const inlineKeyboard = mapsUrl ? {
      reply_markup: {
        inline_keyboard: [
          [{ text: "⌜🌍⌟ ☇ オープンロケーション", url: mapsUrl }]
        ]
      }
    } : null;

    try {
      if (processingMsg && processingMsg.photo && typeof processingMsg.message_id !== "undefined") {
        await ctx.telegram.editMessageCaption(
          processingMsg.chat.id,
          processingMsg.message_id,
          undefined,
          caption,
          { parse_mode: "HTML", ...(inlineKeyboard ? inlineKeyboard : {}) }
        );
      } else if (typeof thumbnailUrl !== "undefined" && thumbnailUrl) {
        await ctx.replyWithPhoto(thumbnailUrl, {
          caption,
          parse_mode: "HTML",
          ...(inlineKeyboard ? inlineKeyboard : {})
        });
      } else {
        if (inlineKeyboard) {
          await ctx.reply(caption, { parse_mode: "HTML", ...inlineKeyboard });
        } else {
          await ctx.reply(caption, { parse_mode: "HTML" });
        }
      }
    } catch (e) {
      if (mapsUrl) {
        await ctx.reply(caption + `📍 ☇ Maps: ${mapsUrl}`, { parse_mode: "HTML" });
      } else {
        await ctx.reply(caption, { parse_mode: "HTML" });
      }
    }

  } catch (err) {
    await ctx.reply("❌ ☇ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti");
  }
});


bot.command("addkey", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  const args = ctx.message.text.split(" ");
  const password = args[1];
  const reply = ctx.message.reply_to_message;

  if (!password) return ctx.reply("❌ Usage: /addkey <password>\n\nReply to a .js file");
  if (!reply?.document) return ctx.reply("❌ Reply to a .js file");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("❌ Only .js files supported");

  try {
    const progressMsg = await ctx.reply("⏳ MENAMBAHKAN PASSWORD...");

    const originalFileName = reply.document.file_name;
    const downloadedPath = await downloadFile(reply.document.file_id, originalFileName);
    
    let code = await fs.readFile(downloadedPath, 'utf8');

    const passwordRequires = [
      "const readline = require('readline')",
      "const crypto = require('crypto')"
    ];

    passwordRequires.forEach(passwordReq => {
      const requireName = passwordReq.split('require(')[0].trim();
      const regex = new RegExp(`(const|let|var)\\s+${requireName.split(' ')[1]}\\s*=\\s*require\\([^)]+\\);?\\n?`, 'g');
      code = code.replace(regex, '');
    });

    const passwordCode = `const readline = require("readline");
const crypto = require('crypto');

function checkPassword() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  let attempts = 0;
  const maxAttempts = 3;

  function askPassword() {
    rl.question("🔐 Enter password: ", (input) => {
      const inputHash = crypto.createHash('sha256').update(input).digest('hex');
      const passwordHash = crypto.createHash('sha256').update("${password}").digest('hex');
      
      if (inputHash === passwordHash) {
        console.log("✅ Access granted!");
        rl.close();
        startBot();
      } else {
        attempts++;
        console.log(\`❌ Invalid password! Attempts: \${attempts}/\${maxAttempts}\`);
        
        if (attempts >= maxAttempts) {
          console.log("🚫 Maximum attempts reached!");
          rl.close();
          process.exit(1);
        } else {
          askPassword();
        }
      }
    });
  }

  setTimeout(() => {
    console.log("⏰ Security timeout reached!");
    rl.close();
    process.exit(1);
  }, 30000);

  askPassword();
}

function startBot() {
${code}
}

if (process.argv.includes('--bypass') || process.argv.includes('--no-password')) {
  console.log("🚫 Bypass attempt detected!");
  process.exit(1);
}

checkPassword();
`;

    const obfuscated = await JsConfuser.obfuscate(passwordCode, invisible);
    const outputFileName = `secured-${originalFileName}`;
    const outputPath = path.join(__dirname, 'downloads', outputFileName);
    await fs.writeFile(outputPath, obfuscated.code || obfuscated);

    await ctx.replyWithDocument(
      {
        source: outputPath,
        filename: outputFileName
      },
      {
        caption: `✅ *Password Protection Added!*

\`\`\`
🔐 SECURITY DETAILS:
• Password: ${password}
• Timeout: 30 seconds  
• Max Attempts: 3
• SHA-256 Encryption
• Anti-Bypass Protection
• Zero-Width Obfuscation
• Self-Defending Code
• Duplicate Require Cleanup
\`\`\`

*Usage:* 
\`\`\`bash
node ${outputFileName}
\`\`\`

*Config:* Invisible Obfuscation
*Status:* 🔒 Password Protected`,
        parse_mode: 'Markdown'
      }
    );

    await ctx.deleteMessage(progressMsg.message_id);

  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
  }
});

bot.command("obfhtml", async (ctx) => {
    let loadingMessageId = null;
    
    try {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.reply('❌ Harus reply ke file .html', { 
                parse_mode: 'Markdown',
                reply_to_message_id: ctx.message.message_id
            });
        }

        const file = ctx.message.reply_to_message.document;
        if (!file.file_name.endsWith(".html")) {
            return ctx.reply('❌ File harus berekstensi .html', { 
                parse_mode: 'Markdown',
                reply_to_message_id: ctx.message.message_id
            });
        }

        const htmlStages = [
            { text: "⸙ Mengunduh file HTML...", progress: 20 },
            { text: "⌭ Mempersiapkan payload...", progress: 40 },
            { text: "⨀ Inisialisasi obfuscation...", progress: 60 },
            { text: "ⵌ Transformasi kode...", progress: 80 },
            { text: "⳼ Finalisasi enkripsi...", progress: 100 }
        ];

        const message1 = `${htmlStages[0].text}\n\n${getProgressBar(htmlStages[0].progress)}`;
        const progressMsg = await ctx.reply(message1, { parse_mode: 'Markdown' });
        loadingMessageId = progressMsg.message_id;
        await new Promise(resolve => setTimeout(resolve, 1000));

        const filePath = await downloadFile(file.file_id, file.file_name);
        
        const message2 = `${htmlStages[1].text}\n\n${getProgressBar(htmlStages[1].progress)}`;
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessageId, null, message2, { parse_mode: 'Markdown' });
        await new Promise(resolve => setTimeout(resolve, 1500));

        const fileContent = fs.readFileSync(filePath, 'utf8');
        
        const message3 = `${htmlStages[2].text}\n\n${getProgressBar(htmlStages[2].progress)}`;
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessageId, null, message3, { parse_mode: 'Markdown' });
        await new Promise(resolve => setTimeout(resolve, 2000));

        const b64 = Buffer.from(fileContent, "utf8").toString("base64");
        const loader = `(function(){try{var d=atob("${b64}");document.open();document.write(d);document.close();}catch(e){console.error(e);document.body.innerText="Failed to load encrypted HTML. Enable JavaScript."}})();`;

        const obfuscationConfig = getBrowserObfuscationConfig();
        const obfuscated = await JsConfuser.obfuscate(loader, obfuscationConfig);
        let obfuscatedCode = obfuscated.code || obfuscated;
        
        if (typeof obfuscatedCode !== "string") {
            throw new Error("Hasil obfuscation bukan string");
        }

        if (!obfuscatedCode || obfuscatedCode.length < 10) {
            throw new Error("Hasil obfuscation tidak valid / terlalu pendek");
        }

        const message4 = `${htmlStages[3].text}\n\n${getProgressBar(htmlStages[3].progress)}`;
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessageId, null, message4, { parse_mode: 'Markdown' });
        await new Promise(resolve => setTimeout(resolve, 1000));

        const encryptedHtml = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Encoded Lolipop</title>
<script>
${obfuscatedCode}
</script>
</head>
<body>
<noscript>Lolipop No Mercy</noscript>
</body>
</html>`;

        const encryptedPath = path.join(__dirname, 'results', `encrypted-${Date.now()}.html`);
        fs.writeFileSync(encryptedPath, encryptedHtml, 'utf8');

        const message5 = `${htmlStages[4].text}\n\n${getProgressBar(htmlStages[4].progress)}`;
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMessageId, null, message5, { parse_mode: 'Markdown' });
        await new Promise(resolve => setTimeout(resolve, 500));

        await ctx.deleteMessage(loadingMessageId);

        await ctx.replyWithDocument({
            source: encryptedPath,
            filename: `encrypted-${file.file_name}`
        }, {
            caption: `✅ *ENCRYPT HTML BERHASIL!*\n\n📂 File: \`${file.file_name}\`\n\n• Buka file di browser double click untuk melihat hasil.\n• Jika tidak tampil, pastikan JavaScript aktif di browser.`,
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });

        try {
            fs.unlinkSync(filePath);
            fs.unlinkSync(encryptedPath);
        } catch (e) {}

    } catch (error) {
        console.error('❌ Gagal encrypt HTML:', error);
        
        if (loadingMessageId) {
            try {
                await ctx.deleteMessage(loadingMessageId);
            } catch (e) {}
        }
        
        ctx.reply(`❌ Gagal encrypt HTML: ${error.message}`, {
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });
    }
});

function getBrowserObfuscationConfig() {
    return {
        target: "browser",
        preset: "high",
        stringEncoding: true,
        stringSplitting: true,
        stringConcealing: true,
        controlFlowFlattening: true,
        deadCode: true,
        duplicateLiteralsRemoval: true,
        identifierGenerator: "randomized",
        renameVariables: true,
        renameGlobals: true,
        compact: true,
    };
}

bot.command("rosemary", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `rosemary-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk rosemary obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = rosemaryConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `rosemary-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});

bot.command("phantom", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `phantom-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk phantom obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = phantomConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `phantom-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});

bot.command("obfsecurity", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `Security-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk Security Anti Bypass Github Use /antibypass for maximum obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = SecurityConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `Security-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});

bot.command("encsiu", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `Siu-Siu-Calckriky-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk Security Anti Bypass Github Use /antibypass for maximum obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = getSiuCalcrickObfuscationConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `Siu-Siu-Calckrik-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});


bot.command('deobfuscate', async (ctx) => {
    let loadingMessageId = null;
    
    try {
        if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
            return ctx.reply('❌ Please reply to a JavaScript file with this command', { 
                parse_mode: 'Markdown',
                reply_to_message_id: ctx.message.message_id
            });
        }

        const document = ctx.message.reply_to_message.document;
        
        if (!document.file_name.endsWith('.js')) {
            return ctx.reply('❌ Please send a JavaScript file (.js)', { 
                parse_mode: 'Markdown',
                reply_to_message_id: ctx.message.message_id
            });
        }

        let progress = await sendProgressUpdate(ctx, 0);
        loadingMessageId = progress.messageId;

        progress = await sendProgressUpdate(ctx, 1, loadingMessageId);
        await new Promise(resolve => setTimeout(resolve, 1000));

        const filePath = await downloadFile(document.file_id, document.file_name);
        
        progress = await sendProgressUpdate(ctx, 2, loadingMessageId);
        await new Promise(resolve => setTimeout(resolve, 1500));

        const fileContent = fs.readFileSync(filePath, 'utf8');
        const result = await webcrack(fileContent);
        const crackedCode = result.code;

        progress = await sendProgressUpdate(ctx, 3, loadingMessageId);
        await new Promise(resolve => setTimeout(resolve, 2000));

        const finalCode = decodeBase64(crackedCode);

        progress = await sendProgressUpdate(ctx, 4, loadingMessageId);
        await new Promise(resolve => setTimeout(resolve, 1000));

        const outputFileName = `deobfuscated_${Date.now()}.js`;
        const outputPath = path.join(__dirname, 'results', outputFileName);
        
        fs.writeFileSync(outputPath, finalCode, 'utf8');

        if (loadingMessageId) {
            await ctx.deleteMessage(loadingMessageId);
        }

        await ctx.replyWithDocument({
            source: outputPath,
            filename: outputFileName
        }, {
            caption: `✅ Deobfuscation Complete\n\n📊 Statistics:\n• Original: ${(fileContent.length / 1024).toFixed(2)} KB\n• Final: ${(finalCode.length / 1024).toFixed(2)} KB\n• Methods: WebCrack + Universal JavaScript Decoder`,
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });

        const codePreview = finalCode.length > 1500 ? finalCode.substring(0, 1500) + '...' : finalCode;
        await ctx.reply(`📝 Code Preview:\n\n\`\`\`javascript\n${codePreview}\n\`\`\``, {
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });

        try {
            fs.unlinkSync(filePath);
            fs.unlinkSync(outputPath);
        } catch (e) {}

    } catch (error) {
        console.error('Error:', error);
        
        if (loadingMessageId) {
            try {
                await ctx.deleteMessage(loadingMessageId);
            } catch (e) {}
        }
        
        ctx.reply('❌ Error processing file: ' + error.message, {
            parse_mode: 'Markdown',
            reply_to_message_id: ctx.message.message_id
        });
    }
});

bot.command("hardcore", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `hardcore-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk hardcore obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = hardcoreConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `hardcore-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});

bot.command("artillery", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `artillery-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk artillery obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = artilleryConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `artillery-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});

bot.command("balanced", async (ctx) => {
  users.add(ctx.from.id);
  saveUsers(users);

  if (!ctx.message.reply_to_message || !ctx.message.reply_to_message.document) {
    return ctx.reply("❌ ☇ Reply dengan file berformat .js");
  }

  const file = ctx.message.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return ctx.reply("❌ ☇ Hanya file .js yang didukung");
  }

  const outputPath = path.join(__dirname, `balanced-encrypted-${file.file_name}`);

  try {
    const progressMessage = await ctx.reply(`⏳ ☇ Tunggu sebentar sedang mengenkripsi File`);

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    log(`✅ ☇ Mengunduh file untuk balanced obfuscation: ${file.file_name}`);
    const response = await fetch(String(fileLink));
    let fileContent = await response.text();

    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`❌ ☇ Kode tidak valid: ${syntaxError.message}`);
    }

    const conf = balancedConfig();
    const obfuscated = await JsConfuser.obfuscate(fileContent, conf);
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("❌ ☇ Hasil obfuscation bukan string");
    }

    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`❌ ☇ Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await fs.writeFile(outputPath, obfuscatedCode);

    await ctx.replyWithDocument(
      { source: outputPath, filename: `balanced-encrypted-${file.file_name}` },
      { caption: "✅ ☇ File berhasil di enkripsi di sarankan reply dokumen ini dengan antibypass agar aman dari orang hama" }
    );

    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  } catch (error) {
    await ctx.reply(
      `❌ ☇ Kesalahan: ${error.message || "tidak diketahui"} Coba lagi dengan kode javascript yang valid`
    );
    if (await fs.pathExists(outputPath)) {
      await fs.unlink(outputPath);
    }
  }
});


async function handleHtmlDecryption(ctx, buffer, fileName, processingMsg) {
    let content = Buffer.from(buffer).toString('utf8');
    const originalContent = content;
    
    await ctx.telegram.editMessageText(
        processingMsg.chat.id,
        processingMsg.message_id,
        null,
        "🔍 Mendeteksi metode enkripsi..."
    );

    const encryptionInfo = detectEncryptionMethod(content);
    
    await ctx.telegram.editMessageText(
        processingMsg.chat.id,
        processingMsg.message_id,
        null,
        `🛡️ Metode terdeteksi: ${encryptionInfo.methods.join(', ') || 'Tidak terdeteksi'}\nMulai decyrecpt...`
    );

    let decryptedContent = content;
    let decryptionSteps = [];

    for (let i = 0; i < 10; i++) {
        const beforeDecryption = decryptedContent;
        decryptedContent = advancedDecryptHtml(decryptedContent);
        
        if (decryptedContent === beforeDecryption) {
            break;
        }
        
        decryptionSteps.push(`Layer ${i + 1}: ${detectEncryptionMethod(decryptedContent).methods[0] || 'Unknown'}`);
    }

    const isChanged = decryptedContent !== originalContent;
    const newFileName = isChanged ? `DECYRECPTED_${fileName}` : `UNCHANGED_${fileName}`;

    let analysisMessage = `📊 **HASIL DECYRCPT**\n`;
    analysisMessage += `📁 File: ${fileName}\n`;
    analysisMessage += `🔍 Metode terdeteksi: ${encryptionInfo.methods.join(', ') || 'Tidak ada enkripsi'}\n`;
    analysisMessage += `🛡️ Tingkat keamanan: ${encryptionInfo.securityLevel}/10\n`;
    analysisMessage += `🔁 Layer decryption: ${decryptionSteps.length}\n`;
    analysisMessage += `📝 Status: ${isChanged ? '✅ BERHASIL DECYRCPT' : '❌ TIDAK TERDECRYPT'}\n\n`;
    
    if (decryptionSteps.length > 0) {
        analysisMessage += `📋 Proses decryption:\n${decryptionSteps.slice(0, 5).join('\n')}`;
        if (decryptionSteps.length > 5) {
            analysisMessage += `\n...dan ${decryptionSteps.length - 5} layer lainnya`;
        }
    }

    await ctx.reply(analysisMessage);

    await ctx.replyWithDocument({
        source: Buffer.from(decryptedContent, 'utf8'),
        filename: newFileName,
        caption: `🔓 ${isChanged ? 'File berhasil di-decyrecpt!' : 'File tidak terenkripsi'}`
    });

    if (decryptedContent.length < 2000) {
        const preview = decryptedContent.substring(0, 1500);
        await ctx.reply(`👁️ **PREVIEW:**\n\`\`\`html\n${preview}\n\`\`\``);
    }

    await ctx.telegram.deleteMessage(processingMsg.chat.id, processingMsg.message_id);
}

function detectEncryptionMethod(content) {
    const methods = [];
    let securityLevel = 0;

    if (/eval\s*\(\s*function/.test(content)) {
        methods.push('Eval Function');
        securityLevel += 3;
    }
    
    if (/\\x[0-9A-Fa-f]{2}/g.test(content)) {
        methods.push('Hex Escape');
        securityLevel += 2;
    }
    
    if (/%[0-9A-Fa-f]{2}/g.test(content)) {
        methods.push('URL Encoding');
        securityLevel += 1;
    }
    
    if (/(?:String\.)?fromCharCode\([^)]+\)/g.test(content)) {
        methods.push('CharCode Encoding');
        securityLevel += 2;
    }
    
    if (/atob\([^)]+\)/g.test(content)) {
        methods.push('Base64 Decode');
        securityLevel += 2;
    }
    
    if (/\b[A-Za-z0-9+/]{20,}={0,2}\b/g.test(content)) {
        methods.push('Base64 Strings');
        securityLevel += 1;
    }
    
    if (/unescape\([^)]+\)/g.test(content)) {
        methods.push('Unescape');
        securityLevel += 1;
    }
    
    if (/decodeURIComponent\([^)]+\)/g.test(content)) {
        methods.push('URI Decode');
        securityLevel += 1;
    }
    
    if (/\b[0-9a-fA-F]{8,}/g.test(content) && content.match(/\b[0-9a-fA-F]{8,}/g).length > 5) {
        methods.push('Hex Strings');
        securityLevel += 3;
    }
    
    if (/\\u[0-9a-fA-F]{4}/g.test(content)) {
        methods.push('Unicode Escape');
        securityLevel += 2;
    }
    
    if (/document\.write\([^)]+\)/g.test(content) && content.includes('eval')) {
        methods.push('Document Write + Eval');
        securityLevel += 4;
    }
    
    if (/setTimeout\([^)]+\)/g.test(content) && content.includes('eval')) {
        methods.push('SetTimeout + Eval');
        securityLevel += 3;
    }

    securityLevel = Math.min(securityLevel, 10);

    return {
        methods,
        securityLevel
    };
}

function advancedDecryptHtml(content) {
    try {
        let decrypted = content;
        
        const base64Patterns = [
            /atob\s*\(\s*['"]([A-Za-z0-9+/=]+)['"]\s*\)/g,
            /window\.atob\s*\(\s*['"]([A-Za-z0-9+/=]+)['"]\s*\)/g,
            /(['"])([A-Za-z0-9+/=]{20,})\1/g
        ];
        
        base64Patterns.forEach(pattern => {
            decrypted = decrypted.replace(pattern, (match, p1, p2) => {
                const base64Str = p2 || p1;
                try {
                    const decoded = Buffer.from(base64Str, 'base64').toString('utf8');
                    if (isValidDecoded(decoded)) {
                        return decoded;
                    }
                } catch (e) {}
                return match;
            });
        });

        decrypted = decrypted.replace(/\\x([0-9A-Fa-f]{2})/g, (match, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
        });

        decrypted = decrypted.replace(/%([0-9A-Fa-f]{2})/g, (match, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
        });

        decrypted = decrypted.replace(/\\u([0-9a-fA-F]{4})/g, (match, hex) => {
            return String.fromCharCode(parseInt(hex, 16));
        });

        const charCodePatterns = [
            /String\.fromCharCode\s*\(\s*([^)]+)\s*\)/g,
            /fromCharCode\s*\(\s*([^)]+)\s*\)/g
        ];
        
        charCodePatterns.forEach(pattern => {
            decrypted = decrypted.replace(pattern, (match, codes) => {
                try {
                    const numbers = codes.split(',').map(num => {
                        const cleanNum = num.trim().replace(/[^\d]/g, '');
                        return parseInt(cleanNum) || 0;
                    }).filter(num => num > 0);
                    
                    if (numbers.length > 0) {
                        return String.fromCharCode(...numbers);
                    }
                } catch (e) {}
                return match;
            });
        });

        decrypted = decrypted.replace(/eval\s*\(\s*["']([^"']+)["']\s*\)/g, (match, code) => {
            return code;
        });

        decrypted = decrypted.replace(/unescape\s*\(\s*['"]([^'"]+)['"]\s*\)/g, (match, str) => {
            try {
                return decodeURIComponent(str.replace(/\%/g, '%'));
            } catch (e) {}
            return match;
        });

        decrypted = decrypted.replace(/decodeURIComponent\s*\(\s*['"]([^'"]+)['"]\s*\)/g, (match, str) => {
            try {
                return decodeURIComponent(str);
            } catch (e) {}
            return match;
        });

        const hexStringRegex = /\b([0-9a-fA-F]{8,})\b/g;
        let hexMatch;
        while ((hexMatch = hexStringRegex.exec(decrypted)) !== null) {
            const hexStr = hexMatch[1];
            if (hexStr.length % 2 === 0) {
                try {
                    let decoded = '';
                    for (let i = 0; i < hexStr.length; i += 2) {
                        const byte = hexStr.substr(i, 2);
                        decoded += String.fromCharCode(parseInt(byte, 16));
                    }
                    if (isValidDecoded(decoded)) {
                        decrypted = decrypted.replace(hexStr, decoded);
                    }
                } catch (e) {}
            }
        }

        const obfuscationPatterns = [
            /document\.write\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
            /setTimeout\s*\(\s*['"]([^'"]+)['"]\s*,\s*\d+\s*\)/g,
            /setInterval\s*\(\s*['"]([^'"]+)['"]\s*,\s*\d+\s*\)/g
        ];
        
        obfuscationPatterns.forEach(pattern => {
            decrypted = decrypted.replace(pattern, '$1');
        });

        return decrypted;
    } catch (error) {
        console.error('Decryption error:', error);
        return content;
    }
}

function isValidDecoded(str) {
    if (!str || str.length < 2) return false;
    if (str.includes('�')) return false;
    if (/[^\x20-\x7E]/.test(str) && str.length < 10) return false;
    
    const validPatterns = [
        /<[a-z][\s\S]*>/i,
        /function\s*\(/,
        /var\s+\w+/,
        /document\./,
        /window\./,
        /\.innerHTML/,
        /\.style\./,
        /http:\/\//,
        /https:\/\//,
        /\.js/,
        /\.css/,
        /\.html?/
    ];
    
    return validPatterns.some(pattern => pattern.test(str)) || 
           (str.length > 10 && /[a-zA-Z]/.test(str) && /[0-9]/.test(str));
}


function escapeHtml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function getFolderStructure(files) {
    const structure = {};
    
    files.forEach(file => {
        const parts = file.filename.split('/');
        let current = structure;
        
        parts.forEach((part, index) => {
            if (index === parts.length - 1) {
                current[part] = '📄';
            } else {
                if (!current[part]) {
                    current[part] = {};
                }
                current = current[part];
            }
        });
    });
    
    return formatStructure(structure);
}

function formatStructure(obj, level = 0) {
    let result = '';
    const indent = '  '.repeat(level);
    
    Object.keys(obj).sort().forEach(key => {
        if (obj[key] === '📄') {
            result += `${indent}📄 ${key}\n`;
        } else {
            result += `${indent}📁 ${key}/\n`;
            result += formatStructure(obj[key], level + 1);
        }
    });
    
    return result;
}

function extractFormInformation($, baseUrl) {
    const forms = [];
    const loginForms = [];
    
    $('form').each((i, formElem) => {
        const $form = $(formElem);
        const action = $form.attr('action');
        const method = $form.attr('method') || 'GET';
        const formId = $form.attr('id') || `form_${i}`;
        
        const formData = {
            id: formId,
            action: action ? new URL(action, baseUrl).href : baseUrl,
            method: method.toUpperCase(),
            fields: []
        };
        
        $form.find('input, textarea, select').each((j, fieldElem) => {
            const $field = $(fieldElem);
            const fieldType = $field.attr('type') || fieldElem.name;
            const fieldName = $field.attr('name') || $field.attr('id') || `field_${j}`;
            const placeholder = $field.attr('placeholder') || '';
            const required = $field.attr('required') ? true : false;
            
            formData.fields.push({
                name: fieldName,
                type: fieldType,
                placeholder: placeholder,
                required: required
            });
        });
        
        forms.push(formData);
        
        if (isLoginForm($form)) {
            loginForms.push({
                ...formData,
                placeholder: extractLoginPlaceholder($form)
            });
        }
    });
    
    return { forms, loginForms };
}

function isLoginForm($form) {
    const html = $form.html().toLowerCase();
    const hasPassword = $form.find('input[type="password"]').length > 0;
    const hasUsername = $form.find('input[type="text"][name*="user"], input[type="email"], input[name*="user"], input[name*="mail"]').length > 0;
    const hasLoginKeywords = /login|signin|sign.in|log.in|auth|authenticate/i.test(html);
    
    return hasPassword && (hasUsername || hasLoginKeywords);
}

function extractLoginPlaceholder($form) {
    const placeholders = [];
    
    const usernameField = $form.find('input[type="text"], input[type="email"], input[name*="user"], input[name*="mail"]');
    if (usernameField.length > 0) {
        const placeholder = usernameField.attr('placeholder');
        if (placeholder) {
            placeholders.push(`Username: ${placeholder}`);
        }
    }
    
    const passwordField = $form.find('input[type="password"]');
    if (passwordField.length > 0) {
        const placeholder = passwordField.attr('placeholder');
        if (placeholder) {
            placeholders.push(`Password: ${placeholder}`);
        }
    }
    
    return placeholders.length > 0 ? placeholders.join(', ') : 'No placeholder detected';
}

async function extractCompleteWebsite(targetUrl) {
    const tempDir = `./temp_website_${Date.now()}`;
    if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
    }

    const files = [];
    const visitedUrls = new Set();
    let baseUrl;
    
    try {
        baseUrl = new URL(targetUrl).origin;
    } catch (error) {
        throw new Error('URL tidak valid');
    }

    async function downloadFileWeb(fileUrl, fileType, subfolder = '') {
        if (visitedUrls.has(fileUrl)) return null;
        visitedUrls.add(fileUrl);

        try {
            const response = await axios.get(fileUrl, {
                timeout: 15000,
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': '*/*'
                },
                validateStatus: function (status) {
                    return status >= 200 && status < 400;
                }
            });

            let filename = path.basename(new URL(fileUrl).pathname);
            if (!filename || filename === '/' || path.extname(filename) === '') {
                const extensions = {
                    'css': 'css',
                    'js': 'js',
                    'image': 'png',
                    'html': 'html',
                    'asset': 'ico',
                    'json': 'json',
                    'xml': 'xml',
                    'font': 'woff'
                };
                filename = `file.${extensions[fileType] || 'bin'}`;
            }

            filename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
            
            const folderPath = path.join(tempDir, subfolder);
            if (!fs.existsSync(folderPath)) {
                fs.mkdirSync(folderPath, { recursive: true });
            }

            const filePath = path.join(folderPath, filename);
            fs.writeFileSync(filePath, response.data);

            const fileInfo = {
                filename: subfolder ? `${subfolder}/${filename}` : filename,
                path: filePath,
                type: fileType,
                url: fileUrl,
                size: response.data.length
            };

            files.push(fileInfo);
            console.log(`✅ Downloaded: ${fileInfo.filename}`);
            return fileInfo;
        } catch (error) {
            console.log(`❌ Failed: ${fileUrl} - ${error.message}`);
            return null;
        }
    }

    console.log(`📥 Fetching main page: ${targetUrl}`);
    const mainResponse = await axios.get(targetUrl, {
        timeout: 20000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        },
        validateStatus: function (status) {
            return status >= 200 && status < 400;
        }
    });

    const mainHtml = mainResponse.data;
    const $ = cheerio.load(mainHtml);

    const { forms, loginForms } = extractFormInformation($, baseUrl);

    const mainHtmlPath = path.join(tempDir, 'index.html');
    fs.writeFileSync(mainHtmlPath, mainHtml);
    files.push({ 
        filename: 'index.html', 
        path: mainHtmlPath, 
        type: 'html', 
        url: targetUrl,
        size: mainHtml.length
    });

    const formDataPath = path.join(tempDir, 'forms_data.json');
    fs.writeFileSync(formDataPath, JSON.stringify({
        loginForms: loginForms,
        otherForms: forms.filter(form => !loginForms.some(loginForm => loginForm.id === form.id)),
        extractedAt: new Date().toISOString(),
        url: targetUrl
    }, null, 2));
    
    files.push({
        filename: 'forms_data.json',
        path: formDataPath,
        type: 'json',
        url: `${targetUrl}#forms`,
        size: fs.statSync(formDataPath).size
    });

    console.log('🎨 Extracting CSS files...');
    const cssPromises = [];
    $('link[rel="stylesheet"]').each((i, elem) => {
        const href = $(elem).attr('href');
        if (href) {
            try {
                const cssUrl = new URL(href, baseUrl).href;
                cssPromises.push(downloadFileWeb(cssUrl, 'css', 'css'));
            } catch (error) {
                console.log(`Invalid CSS URL: ${href}`);
            }
        }
    });

    console.log('⚡ Extracting JavaScript files...');
    const jsPromises = [];
    $('script[src]').each((i, elem) => {
        const src = $(elem).attr('src');
        if (src) {
            try {
                const jsUrl = new URL(src, baseUrl).href;
                jsPromises.push(downloadFileWeb(jsUrl, 'js', 'js'));
            } catch (error) {
                console.log(`Invalid JS URL: ${src}`);
            }
        }
    });

    console.log('🖼️ Extracting images...');
    const imgPromises = [];
    $('img[src]').each((i, elem) => {
        const src = $(elem).attr('src');
        if (src) {
            try {
                const imgUrl = new URL(src, baseUrl).href;
                imgPromises.push(downloadFileWeb(imgUrl, 'image', 'images'));
            } catch (error) {
                console.log(`Invalid Image URL: ${src}`);
            }
        }
    });

    console.log('📚 Extracting other assets...');
    const assetPromises = [];
    $('link[rel*="icon"], link[rel*="apple"], link[href*=".woff"], link[href*=".ttf"], link[href*=".svg"]').each((i, elem) => {
        const href = $(elem).attr('href');
        if (href) {
            try {
                const assetUrl = new URL(href, baseUrl).href;
                assetPromises.push(downloadFileWeb(assetUrl, 'asset', 'assets'));
            } catch (error) {
                console.log(`Invalid Asset URL: ${href}`);
            }
        }
    });

    console.log('📋 Extracting JSON data files...');
    const jsonPromises = [];

    $('a[href]').each((i, elem) => {
        const href = $(elem).attr('href');
        if (href && (href.endsWith('.json') || href.includes('.json?'))) {
            try {
                const jsonUrl = new URL(href, baseUrl).href;
                jsonPromises.push(downloadFileWeb(jsonUrl, 'json', 'data'));
            } catch (error) {
                console.log(`Invalid JSON URL: ${href}`);
            }
        }
    });

    const commonDataEndpoints = [
        'data.json', 'config.json', 'settings.json', 'manifest.json',
        'package.json', 'composer.json', 'api.json', 'db.json',
        'users.json', 'products.json', 'posts.json', 'articles.json'
    ];

    for (const endpoint of commonDataEndpoints) {
        try {
            const dataUrl = `${baseUrl}/${endpoint}`;
            jsonPromises.push(downloadFileWeb(dataUrl, 'json', 'api-data'));
        } catch (error) {
            console.log(`Invalid data endpoint: ${endpoint}`);
        }
    }

    await Promise.allSettled([
        ...cssPromises,
        ...jsPromises, 
        ...imgPromises,
        ...assetPromises,
        ...jsonPromises
    ]);

    console.log('🔍 Looking for configuration files...');
    const configFiles = [
        'robots.txt', 'sitemap.xml', '.htaccess', 'web.config',
        'package.json', 'composer.json', 'config.json', 'settings.json',
        'manifest.json', 'firebase.json', 'config.php', 'wp-config.php'
    ];

    const configPromises = configFiles.map(configFile => 
        downloadFileWeb(`${baseUrl}/${configFile}`, 'config', 'config')
    );

    await Promise.allSettled(configPromises);

    return { 
        tempDir, 
        files, 
        mainHtml,
        forms,
        loginForms
    };
}

async function createWebsiteZip(websiteData, originalUrl) {
    return new Promise((resolve, reject) => {
        const zipPath = `./website_complete_${Date.now()}.zip`;
        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', { 
            zlib: { level: 9 } 
        });

        output.on('close', () => {
            console.log(`ZIP created: ${archive.pointer()} total bytes`);
            resolve(zipPath);
        });

        archive.on('error', (err) => {
            reject(err);
        });

        archive.pipe(output);

        const readmeContent = `Website Source Code Extraction\n
URL: ${originalUrl}
Extracted: ${new Date().toISOString()}
Total Files: ${websiteData.files.length}
Login Forms Found: ${websiteData.loginForms.length}
Other Forms Found: ${websiteData.forms.length}

File Structure:
${websiteData.files.map(f => `- ${f.filename} (${f.type}, ${f.size} bytes)`).join('\n')}

Extracted Lolipop Bot`;

        archive.append(readmeContent, { name: 'README.txt' });

        websiteData.files.forEach(file => {
            if (fs.existsSync(file.path)) {
                archive.file(file.path, { name: file.filename });
            }
        });

        archive.finalize();
    });
}

const zeroWidthMap = {
    '\u200B': '', '\u200C': '', '\u200D': '', '\uFEFF': '', 
    '\u2060': '', '\u180E': '', '\u200E': '', '\u200F': '',
    '\u202A': '', '\u202B': '', '\u202C': '', '\u202D': '',
    '\u202E': '', '\u2061': '', '\u2062': '', '\u2063': '',
    '\u2064': '', '\u2065': '', '\u2066': '', '\u2067': '',
    '\u2068': '', '\u2069': '', '\u206A': '', '\u206B': '',
    '\u206C': '', '\u206D': '', '\u206E': '', '\u206F': ''
};

const hexConstMap = {
    '0x0': '0', '0x1': '1', '0x2': '2', '0x3': '3', '0x4': '4',
    '0x5': '5', '0x6': '6', '0x7': '7', '0x8': '8', '0x9': '9',
    '0xa': 'a', '0xb': 'b', '0xc': 'c', '0xd': 'd', '0xe': 'e', 
    '0xf': 'f', '0x10': 'g', '0x11': 'h', '0x12': 'i', '0x13': 'j',
    '0x20': ' ', '0x22': '"', '0x27': "'", '0x2f': '/', '0x3a': ':',
    '0x2e': '.', '0x5b': '[', '0x5d': ']', '0x7b': '{', '0x7d': '}'
};

const customMaps = {
    '_0x1': 'h', '_0x2': 't', '_0x3': 'p', '_0x4': 's', '_0x5': ':',
    '_0x6': '/', '_0x7': '.', '_0x8': 'c', '_0x9': 'o', '_0xa': 'm',
    '_0b1': 'a', '_0b2': 'e', '_0b3': 'i', '_0b4': 'u', '_0b5': 'l',
    '_0o1': '0', '_0o2': '1', '_0o3': '2', '_0o4': '3', '_0o5': '4'
};

const jpMap = {
    '置': 'h', '装': 't', '化': 'p', '読': 's', '難': ':',
    '再': '/', '構': '.', '設': 'c', '定': 'o', '義': 'm',
    '変': 'a', '数': 'e', '機': 'i', '能': 'u', '関': 'l',
    '方': '0', '法': '1', '種': '2', '類': '3', '形': '4',
    '実': '5', '行': '6', '処': '7', '理': '8', '結': '9',
    '果': 'w', '確': 'x', '認': 'y', '表': 'z', '示': 'A',
    '内': 'B', '容': 'C', '情': 'D', '報': 'E', 'デ': 'F',
    'ー': 'G', 'タ': 'H', 'ベ': 'I', 'ース': 'J', 'フ': 'K',
    'ァ': 'L', 'イ': 'M', 'ル': 'N', '難読化': 'http', 
    '装飾': 'https', '変換': '://', '文字列': 'www',
    '暗号': 'com', '復号': 'net', '処理': 'org'
};

const keywords = [
    "break","case","catch","class","const","continue",
    "debugger","default","delete","do","else","export",
    "extends","finally","for","function","if","import",
    "in","instanceof","new","return","super","switch",
    "this","throw","try","typeof","var","void","while",
    "with","yield","enum","await","implements","package",
    "protected","interface","private","public","null","true","false"
];

function decodeBase64(str) {
    if (typeof str !== 'string') return str;
    
    let decoded = str;
    let previous;
    let iterations = 0;
    
    do {
        previous = decoded;
        
        const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
        if (decoded.length > 5 && base64Regex.test(decoded)) {
            try {
                const base64Decoded = Buffer.from(decoded, 'base64').toString('utf8');
                if (base64Decoded.length > 0 && !base64Decoded.includes('�')) {
                    decoded = base64Decoded;
                }
            } catch (e) {}
        }

        if (/\\x[0-9A-Fa-f]{2}/.test(decoded)) {
            try {
                decoded = decoded.replace(/\\x([0-9A-Fa-f]{2})/g, (match, hex) => {
                    return String.fromCharCode(parseInt(hex, 16));
                });
            } catch (e) {}
        }

        if (/\\u[0-9A-Fa-f]{4}/.test(decoded)) {
            try {
                decoded = decoded.replace(/\\u([0-9A-Fa-f]{4})/g, (match, hex) => {
                    return String.fromCharCode(parseInt(hex, 16));
                });
            } catch (e) {}
        }

        const pureHexRegex = /^[0-9A-Fa-f]+$/;
        if (pureHexRegex.test(decoded) && decoded.length % 2 === 0) {
            try {
                const hexDecoded = Buffer.from(decoded, 'hex').toString('utf8');
                if (hexDecoded && !hexDecoded.includes('�')) {
                    decoded = hexDecoded;
                }
            } catch (e) {}
        }

        if (decoded.length > 3 && /[a-zA-Z]/.test(decoded)) {
            try {
                decoded = decoded.replace(/[a-zA-Z]/g, function(c) {
                    const code = c.charCodeAt(0);
                    if ((code >= 65 && code <= 77) || (code >= 97 && code <= 109)) {
                        return String.fromCharCode(code + 13);
                    }
                    if ((code >= 78 && code <= 90) || (code >= 110 && code <= 122)) {
                        return String.fromCharCode(code - 13);
                    }
                    return c;
                });
            } catch (e) {}
        }

        if ((decoded.startsWith('[') && decoded.endsWith(']')) || decoded.includes('String.fromCharCode')) {
            try {
                if (decoded.startsWith('[') && decoded.endsWith(']')) {
                    const cleanStr = decoded.replace(/[\[\]\s]/g, '');
                    const numbers = cleanStr.split(',').map(Number);
                    if (numbers.every(n => !isNaN(n) && n >= 0 && n <= 255)) {
                        const charDecoded = String.fromCharCode(...numbers);
                        decoded = charDecoded;
                    }
                }
                
                const charCodeRegex = /String\.fromCharCode\(([^)]+)\)/g;
                let match;
                
                while ((match = charCodeRegex.exec(decoded)) !== null) {
                    const codes = match[1].split(',').map(s => parseInt(s.trim(), 10));
                    if (codes.every(n => !isNaN(n))) {
                        const charString = String.fromCharCode(...codes);
                        decoded = decoded.replace(match[0], charString);
                    }
                }
            } catch (e) {}
        }

        if (/\\[0-7]{3}/.test(decoded)) {
            try {
                decoded = decoded.replace(/\\([0-7]{3})/g, (match, octal) => {
                    return String.fromCharCode(parseInt(octal, 8));
                });
            } catch (e) {}
        }

        if (decoded.includes('\\x') || decoded.includes('\\u') || decoded.includes('\\')) {
            try {
                decoded = decoded.replace(/\\x([0-9A-Fa-f]{2})/g, (match, hex) => 
                    String.fromCharCode(parseInt(hex, 16)));
                
                decoded = decoded.replace(/\\u([0-9A-Fa-f]{4})/g, (match, hex) => 
                    String.fromCharCode(parseInt(hex, 16)));
                
                decoded = decoded.replace(/\\([0-7]{3})/g, (match, octal) => 
                    String.fromCharCode(parseInt(octal, 8)));
            } catch (e) {}
        }

        if (decoded.length > 3) {
            try {
                const reversed = decoded.split('').reverse().join('');
                const originalScore = getReadabilityScore(decoded);
                const reversedScore = getReadabilityScore(reversed);
                if (reversedScore > originalScore) {
                    decoded = reversed;
                }
            } catch (e) {}
        }

        if (decoded.includes('\\/') || decoded.includes('\\"')) {
            try {
                const jsonDecoded = JSON.parse(`"${decoded}"`);
                decoded = jsonDecoded;
            } catch (e) {}
        }

        if (decoded.includes('置') || decoded.includes('装') || decoded.includes('化') || decoded.includes('読') || decoded.includes('難')) {
            try {
                for (const [jp, eng] of Object.entries(jpMap)) {
                    decoded = decoded.split(jp).join(eng);
                }
            } catch (e) {}
        }

        if (decoded.includes('_0x') || decoded.includes('_0b') || decoded.includes('_0o')) {
            try {
                for (const [custom, normal] of Object.entries(customMaps)) {
                    decoded = decoded.split(custom).join(normal);
                }
            } catch (e) {}
        }

        if (hasZeroWidthChars(decoded)) {
            try {
                decoded = decodeZeroWidthText(decoded);
            } catch (e) {}
        }

        if (hasHexNumbers(decoded)) {
            try {
                decoded = decodeHexNumbers(decoded);
            } catch (e) {}
        }

        if (isJSObfuscatorPattern(decoded)) {
            try {
                decoded = decodeJSObfuscator(decoded);
            } catch (e) {}
        }

        if (hasHardcoreObfuscation(decoded)) {
            try {
                decoded = decodeHardcoreObfuscation(decoded);
            } catch (e) {}
        }

        if (hasArtilleryObfuscation(decoded)) {
            try {
                decoded = decodeArtilleryObfuscation(decoded);
            } catch (e) {}
        }

        iterations++;
        if (iterations > 15) break;
        
    } while (decoded !== previous);

    return decoded;
}

function getReadabilityScore(str) {
    let score = 0;
    score += (str.match(/[a-zA-Z0-9]/g) || []).length;
    score -= (str.match(/[^\w\s]/g) || []).length * 0.5;
    return score;
}

const hasZeroWidthChars = (str) => {
    const zeroWidthRegex = /[\u200B-\u200F\uFEFF\u180E\u2060-\u206F\u202A-\u202E]/;
    return zeroWidthRegex.test(str);
};

const decodeZeroWidthText = (str) => {
    let decoded = str;
    for (const [zwChar, normalChar] of Object.entries(zeroWidthMap)) {
        decoded = decoded.split(zwChar).join(normalChar);
    }
    decoded = decoded.replace(/[\u200B-\u200F\uFEFF\u180E\u2060-\u206F\u202A-\u202E]/g, '');
    return decoded;
};

const hasHexNumbers = (str) => {
    const hexNumRegex = /0x[0-9A-Fa-f]+/g;
    return hexNumRegex.test(str);
};

const decodeHexNumbers = (str) => {
    return str.replace(/0x([0-9A-Fa-f]+)/g, (match, hex) => {
        const num = parseInt(hex, 16);
        if (num >= 32 && num <= 126) {
            return String.fromCharCode(num);
        }
        return hexConstMap[match] || match;
    });
};

const isJSObfuscatorPattern = (str) => {
    const patterns = [
        /function\s+\w+\(\w+\)\{\s*while\(\w+\)\s*\{\s*\w+=\w+&\w+;\s*\}/,
        /var\s+\w+\s*=\s*\[\s*\];\s*for\s*\(\s*\w+\s*=\s*\d+;\s*\w+\s*<\s*\w+\.length;\s*\w+\s*\+\+\s*\)\s*\{/,
    ];
    return patterns.some(pattern => pattern.test(str));
};

const decodeJSObfuscator = (str) => {
    let decoded = str;
    decoded = decoded.replace(/'\\u200B([^']+?)'/g, (match, content) => `'${decodeZeroWidthText(content)}'`);
    decoded = decoded.replace(/"\\u200C([^"]+?)"/g, (match, content) => `"${decodeZeroWidthText(content)}"`);
    decoded = decoded.replace(/function\s+_0x(\w+)\(\w+\)\{[^}]+\}/g, '');
    return decoded;
};

const hasHardcoreObfuscation = (str) => {
    return /[a-z]‌[a-z]‌[a-z]/.test(str) || 
           /var\s+[a-z]‌+[a-z]\s*=/.test(str) ||
           /const\s+[a-z]‌+[a-z]\s*=/.test(str);
};

const decodeHardcoreObfuscation = (str) => {
    let decoded = str;
    decoded = decoded.replace(/([a-z])‌([a-z])‌([a-z])/g, '$1$2$3');
    decoded = decoded.replace(/(var|const|let)\s+([a-z])‌+([a-z])/g, '$1 $2$3');
    return decoded;
};

const hasArtilleryObfuscation = (str) => {
    const keywordPattern = new RegExp(`(${keywords.join('|')})\\u200B+`, 'g');
    return keywordPattern.test(str);
};

const decodeArtilleryObfuscation = (str) => {
    let decoded = str;
    decoded = decoded.replace(/(break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|finally|for|function|if|import|in|instanceof|new|return|super|switch|this|throw|try|typeof|var|void|while|with|yield|enum|await|implements|package|protected|interface|private|public|null|true|false)\u200B+/g, '$1');
    return decoded;
};

const loadingStages = [
    { text: "📥 Downloading file...", progress: 20 },
    { text: "🔍 Analyzing code structure...", progress: 40 },
    { text: "⚡ Running WebCrack...", progress: 60 },
    { text: "🔓 Applying universal decoder...", progress: 80 },
    { text: "✨ Finalizing results...", progress: 100 }
];

const rosemaryConfig = (overrides = {}) => {
  const mulberry32 = (a) => () => {
    let t = (a += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const seed =
    (Date.now() ^ (typeof performance !== "undefined" ? (performance.now() | 0) : 0)) >>> 0;
  const rnd = mulberry32(seed);

  const idGen = () => {
    const head = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    const tail = head + "0123456789";
    const len = 7 + Math.floor(rnd() * 11);
    let s = head[Math.floor(rnd() * head.length)];
    for (let i = 1; i < len; i++) {
      s += tail[Math.floor(rnd() * tail.length)];
      if (rnd() > 0.84) s += "\u200C";
    }
    return s;
  };

  const base = {
    target: "node",
    compact: true,
    minify: true,

    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: idGen,

    stringEncoding: true,
    stringCompression: true,
    stringConcealing: true,
    stringSplitting: 1,

    controlFlowFlattening: 1,
    flatten: true,
    opaquePredicates: 1,
    dispatcher: true,

    hexadecimalNumbers: true,
    duplicateLiteralsRemoval: true,
    objectExtraction: true,
    movedDeclarations: true,

    deadCode: true,

    globalConcealing: true,
    shuffle: true,

    lock: {
      selfDefending: true,
      integrity: true,
      antiDebug: true,
      tamperProtection: true,
    },
  };

  const nuanced = { ...base };
  if (rnd() > 1) nuanced.stringSplitting = 1;
  if (rnd() > 1) nuanced.opaquePredicates = 1 + rnd() * 1;
  if (rnd() > 1) nuanced.deadCodeInjectionThreshold = 1 + rnd() * 1;

  const conf = { ...nuanced, ...overrides };
  if (overrides.lock && typeof overrides.lock === "object") {
    conf.lock = { ...nuanced.lock, ...overrides.lock };
  }

  if (typeof conf.identifierGenerator === "string") {
    conf.identifierGenerator = idGen;
  }

  return conf;
};

const phantomConfig = () => {
  return {
    target: "node",
    calculator: true,
    compact: true,
    hexadecimalNumbers: true,
    controlFlowFlattening: 0.75,
    deadCode: 0.2,
    dispatcher: true,
    duplicateLiteralsRemoval: 0.75,
    flatten: true,
    globalConcealing: true,
    identifierGenerator: "zeroWidth",
    minify: true,
    movedDeclarations: true,
    objectExtraction: true,
    opaquePredicates: 0.75,
    renameVariables: true,
    renameGlobals: true,
    stringConcealing: true,
    stringCompression: true,
    stringEncoding: true,
    stringSplitting: 0.75,
    rgf: true,
  };
};

const hardcoreConfig = () => {
  const gen = () => {
    const chars = "abcdefghijklmnopqrstuvwxyz";
    let s = "";
    const len = 6 + Math.floor(Math.random() * 30);
    for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s.split("").join("‌");
  };

  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: gen,
    stringEncoding: true,
    controlFlowFlattening: 0.9,
    shuffle: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    lock: {
      selfDefending: true,
      antiDebug: true,
      integrity: true,
      tamperProtection: true,
    },
  };
};

const SecurityConfig = () => {
  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: "mangled",
    controlFlowFlattening: 1.0,
    stringEncoding: true,
    stringCompression: true,
    stringSplitting: 0.8,
    deadCode: true,
    dispatcher: true,
    flatten: true,
    lock: {
      selfDefending: true,
      antiDebug: true
    }
  };
};

const invisible = {
  target: "node",
  compact: true,
  renameVariables: true,
  renameGlobals: true,
  identifierGenerator: "zeroWidth",
  controlFlowFlattening: 1.0,
  stringEncoding: true,
  stringCompression: true,
  stringSplitting: 1.0,
  deadCode: true,
  dispatcher: true,
  flatten: true,
  opaquePredicates: 1.0,
  globalConcealing: true,
  lock: {
    selfDefending: true,
    antiDebug: true,
    integrity: true
  }
};

const getSiuCalcrickObfuscationConfig = () => {
    const generateSiuCalcrickName = () => {
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let randomPart = "";
        for (let i = 0; i < 6; i++) {
            randomPart += chars[Math.floor(Math.random() * chars.length)];
        }
        return `犬LolipopえThe火Obfusate水${randomPart}`;
    };

    return {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: generateSiuCalcrickName,
        stringCompression: true,
        stringEncoding: true,
        stringSplitting: true,
        controlFlowFlattening: 0.95,
        shuffle: true,
        rgf: false,
        flatten: true,
        duplicateLiteralsRemoval: true,
        deadCode: true,
        calculator: true,
        opaquePredicates: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
    };
};

const artilleryConfig = () => {
  const generateTrickyName = () => {
    const zwsp = "‌";
    const safeKeywords = [
      "break","case","catch","class","const","continue",
      "debugger","default","delete","do","else","export",
      "extends","finally","for","function","if","import",
      "in","instanceof","new","return","super","switch",
      "this","throw","try","typeof","var","void","while",
      "with","yield","enum","await","implements","package",
      "protected","interface","private","public","null","true","false"
    ];
    return (
      safeKeywords[Math.floor(Math.random() * safeKeywords.length)] +
      zwsp.repeat(Math.floor(Math.random() * (999 - 5 + 1)) + 5 - 2)
    );
  };

  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: generateTrickyName,
    stringEncoding: true,
    controlFlowFlattening: 1,
    shuffle: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    lock: {
      selfDefending: true,
      antiDebug: true,
      integrity: true,
    },
  };
};

const balancedConfig = () => {
  const randomChars = [
    "Lolipop難読化装置",
    "難Lolipop読化装置",
    "難読Lolipop化装置",
    "難読化Lolipop装置",
    "難読化装Lolipop置",
    "難読化装置Lolipop",
    "難読化装置Lolipop",
    "難読化装Lolipop置",
    "難読化Lolipop装置",
    "難読Lolipop化装置",
    "難Lolipop読化装置",
    "Lolipop難読化装置",
    "Lolipop難読化装置",
    "Lolipop置装化読難",
  ];

  const generateCustomName = () => {
    const length = Math.floor(Math.random() * 4) + 3;
    let name = "";
    for (let i = 0; i < length; i++) {
      name += randomChars[Math.floor(Math.random() * randomChars.length)];
    }
    return name;
  };

  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: () => generateCustomName(),
    stringEncoding: true,
    stringSplitting: true,
    controlFlowFlattening: 0.95,
    shuffle: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
      selfDefending: true,
      antiDebug: true,
      integrity: true,
      tamperProtection: true,
    },
  };
};

// ========== BOT LAUNCH ==========
bot.launch()
  .then(() => {
    console.log('\n╔══════════════════════════════════════╗');
    console.log('║           🤖 BOT ENCRIPTY AKTIF 🤖           ║');
    console.log('╠══════════════════════════════════════╣');
    console.log('║ • Status: ONLINE                    ║');
    console.log('║ • Waktu: ' + new Date().toLocaleTimeString('id-ID') + '              ║');
    console.log('║ • Ready menerima command            ║');
    console.log('╚══════════════════════════════════════╝\n');
    
    log("Bot berhasil dijalankan");
  })
  .catch((err) => {
    console.log('\n╔══════════════════════════════════════╗');
    console.log('║           ❌ BOT ERROR ❌           ║');
    console.log('╠══════════════════════════════════════╣');
    console.log('║ • Gagal launch bot                  ║');
    console.log('║ • Error: ' + err.message.substring(0, 20) + '...       ║');
    console.log('╚══════════════════════════════════════╝\n');
    
    log("Gagal launch bot", err);
  });

process.on("unhandledRejection", (reason) => {
  console.log('\n⚠️  Unhandled Rejection: ' + reason);
  log("Unhandled Rejection", reason);
});

process.on("SIGINT", () => {
  console.log('\n🛑 Bot dimatikan...');
  bot.stop("SIGINT");
});

process.on("SIGTERM", () => {
  console.log('\n🛑 Bot dimatikan...');
  bot.stop("SIGTERM");
});

    console.log('\n╔══════════════════════════════════════╗');
    console.log('║           🤖 BOT ENCRIPTY AKTIF 🤖           ║');
    console.log('╠══════════════════════════════════════╣');
    console.log('║ • Status: ONLINE                    ║');
    console.log('║ • Waktu: ' + new Date().toLocaleTimeString('id-ID') + '              ║');
    console.log('║ • Ready menerima command            ║');
    console.log('╚══════════════════════════════════════╝\n');